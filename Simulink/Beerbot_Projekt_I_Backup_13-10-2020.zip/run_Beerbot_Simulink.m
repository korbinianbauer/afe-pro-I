clear
clc
close all

%set(gcf, 'Position',  [100, 100, 1800, 500])

% Draußen, gerade Fahrt, ca. 5m
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Fri_Jul_31_19-27-54_2020_Program_2.txt";

% Draußen, Drehung auf der Stelle
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Fri_Jul_31_19-29-51_2020_Program_3.txt";

% Draußen, 4x 2s vorwärts + 0.5s Rechtsdrehung
% logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Fri_Jul_31_18-53-13_2020_Program_4.txt";

% Drin, 30cm vor und zurück
% logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_10-16-00_2020_Program_1.txt";

% Drin, 1.5m vorwärts, dann in leichtem Bogen zurück zum Anfang
% logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_11-02-39_2020_Program_1.txt";

% ???
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_11-12-12_2020_Program_4.txt";

% Wohnung, Zimmer, Gang und wieder genau zurück:
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_12-06-23_2020_Program_4.txt";


% Wohnung, Stillstand
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_12-11-20_2020_Program_4.txt";

% Wohnung, Zimmer, Gang und wieder genau zurück
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Tue_Aug__4_14-59-42_2020_Program_4.txt";

% Wohnung, Joystick
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Mon_Aug_10_15-47-28_2020_Program_joystick.txt";



% Outdoor Kalibrierfahrten, Anfang = Ende
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_fahrten_anfang_gleich_ende\Mon_Aug_10_16-39-55_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_fahrten_anfang_gleich_ende\Mon_Aug_10_16-43-09_2020_Program_joystick.txt";
% Straße entlang
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_fahrten_anfang_gleich_ende\Mon_Aug_10_16-53-39_2020_Program_joystick.txt";

%4,5 rechtsdrehungn
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_fahrten_anfang_gleich_ende\Mon_Aug_10_16-47-40_2020_Program_joystick.txt";

%4 linksdrehungn
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_fahrten_anfang_gleich_ende\Mon_Aug_10_16-50-32_2020_Program_joystick.txt";




% Indoor Kalibrierfahrten, Anfang = Ende
% 
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_fahrten_anfang_gleich_ende\Mon_Aug_10_17-37-08_2020_Program_joystick.txt";

% rechtsdrehungen
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_fahrten_anfang_gleich_ende\Mon_Aug_10_17-40-43_2020_Program_joystick.txt";

% linksdrehungen
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_fahrten_anfang_gleich_ende\Mon_Aug_10_17-43-06_2020_Program_joystick.txt";

%
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_fahrten_anfang_gleich_ende\Mon_Aug_10_17-45-51_2020_Program_joystick.txt";

%
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_fahrten_anfang_gleich_ende\Mon_Aug_10_17-53-35_2020_Program_joystick.txt";

% Indoor wheel circ Kalibrierfahrten
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\indoor_umfang_kalibrieren\Mon_Aug_10_17-57-44_2020_Program_joystick.txt";





% Outdoor Testfahrten mit Wheel slip, Anfang = Ende, Mag Calib kaputt,
% unusable

%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip\Sun_Oct_11_09-02-19_2020_Program_joystick.txt";

%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip\Sun_Oct_11_09-05-21_2020_Program_joystick.txt";

%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip\Sun_Oct_11_09-17-12_2020_Program_joystick.txt";


% Test nachdem Wheel slip testfahrten fürn A* weill Compass Calib kaputt
% (?)

%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Mon_Oct_12_11-37-35_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\Mon_Oct_12_11-44-37_2020_Program_joystick.txt";

% Outdoor Testfahrten mit Wheel slip, Anfang = Ende, 2. Versuch

%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_2\Mon_Oct_12_11-50-21_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_2\Mon_Oct_12_11-53-48_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_2\Mon_Oct_12_11-58-22_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_2\Mon_Oct_12_12-00-50_2020_Program_joystick.txt";


% 3. Versuch
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_3\Mon_Oct_12_15-43-12_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_3\Mon_Oct_12_15-45-48_2020_Program_joystick.txt";
logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_3\Mon_Oct_12_15-48-36_2020_Program_joystick.txt";
%logpath = "C:\Users\Besitzer\Box Sync\Documents\FH\AFE\SEM1\Projekt I\Aufzeichnungen Odo+IMU\logs\outdoor_wheel_slip_versuch_3\Mon_Oct_12_15-51-04_2020_Program_joystick.txt";


log = fileToLog(logpath);


bot_wheel_distance = 0.5948; % meter
wheel_circ_correction_factor = 0.971;
wheel_slip_detection_thres = 0.1; % rad/s

timebase = 0.001*[log.Time]';
Left_wheel_dist_data = -0.001*wheel_circ_correction_factor*[log.Right_wheel_dist]';
Right_wheel_dist_data = -0.001*wheel_circ_correction_factor*[log.Left_wheel_dist]';
Compass_Heading = [log.IMU_yaw]';
Acc_x_data = [log.IMU_Acc_x]';
Acc_y_data = [log.IMU_Acc_y]';

heading_initial = Compass_Heading(1);

Left_wheel_dist = [timebase Left_wheel_dist_data];
Right_wheel_dist = [timebase Right_wheel_dist_data];
Compass_heading = [timebase Compass_Heading];
Acc_x = [timebase Acc_x_data];
Acc_y = [timebase Acc_y_data];



simOut = sim('Beerbot_Simulink')


